export interface InvoiceData {
  invoiceNumber: string
  customerName: string
  issueDate: string
  dueDate: string
  items?: Array<{
    id?: number
    productName?: string
    description?: string
    quantity: number
    unitPrice: number
    total: number
  }>
  subtotal: number
  discount: number
  tax: number
  totalAmount: number
  paymentMethod: string
  notes?: string
}

/**
 * Generate HTML invoice template for printing
 */
function generateInvoiceHTML(invoice: InvoiceData): string {
  const itemsHTML =
    invoice.items && Array.isArray(invoice.items) && invoice.items.length > 0
      ? invoice.items
          .map((item) => {
            const itemDescription =
              item.description || item.productName || "Item"
            return `
    <tr>
      <td style="padding: 8px; border-bottom: 1px solid #ddd;">${itemDescription}</td>
      <td style="padding: 8px; border-bottom: 1px solid #ddd; text-align: center;">${item.quantity || 0}</td>
      <td style="padding: 8px; border-bottom: 1px solid #ddd; text-align: right;">$${(item.unitPrice || 0).toFixed(2)}</td>
      <td style="padding: 8px; border-bottom: 1px solid #ddd; text-align: right;">$${(item.total || 0).toFixed(2)}</td>
    </tr>
  `
          })
          .join("")
      : '<tr><td colspan="4" style="padding: 20px; text-align: center; color: #999;">No items</td></tr>'

  return `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Invoice ${invoice.invoiceNumber}</title>
      <style>
        * { margin: 0; padding: 0; }
        body {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          background: #f5f5f5;
          padding: 20px;
        }
        .container {
          max-width: 900px;
          margin: 0 auto;
          background: white;
          padding: 40px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 30px;
          border-bottom: 2px solid #3b82f6;
          padding-bottom: 20px;
        }
        .company-name {
          font-size: 28px;
          font-weight: bold;
          color: #1f2937;
        }
        .invoice-title {
          font-size: 24px;
          font-weight: 600;
          color: #3b82f6;
        }
        .details {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
          margin-bottom: 30px;
        }
        .detail-block {
          padding: 15px;
          background: #f9fafb;
          border-radius: 6px;
        }
        .detail-label {
          font-size: 12px;
          color: #6b7280;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 5px;
        }
        .detail-value {
          font-size: 14px;
          font-weight: 600;
          color: #1f2937;
        }
        table {
          width: 100%;
          margin-bottom: 30px;
          border-collapse: collapse;
        }
        th {
          background: #3b82f6;
          color: white;
          padding: 12px;
          text-align: right;
          font-weight: 600;
        }
        td {
          padding: 12px;
          border-bottom: 1px solid #e5e7eb;
        }
        .summary {
          display: flex;
          justify-content: flex-end;
          margin-bottom: 30px;
        }
        .summary-block {
          width: 300px;
        }
        .summary-row {
          display: flex;
          justify-content: space-between;
          padding: 10px 0;
          border-bottom: 1px solid #e5e7eb;
          font-size: 14px;
        }
        .summary-row.total {
          background: #eff6ff;
          padding: 12px;
          font-weight: 700;
          font-size: 16px;
          color: #1e40af;
          border: 2px solid #3b82f6;
          margin-top: 10px;
        }
        .notes {
          background: #fef3c7;
          border-left: 4px solid #f59e0b;
          padding: 15px;
          margin-top: 20px;
          border-radius: 4px;
        }
        .notes-title {
          font-weight: 600;
          color: #92400e;
          margin-bottom: 5px;
        }
        .notes-content {
          color: #78350f;
          font-size: 13px;
        }
        @media print {
          body { background: white; }
          .container { box-shadow: none; padding: 0; }
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="company-name">Trust Export</div>
          <div class="invoice-title">الفاتورة / Invoice</div>
        </div>

        <div class="details">
          <div class="detail-block">
            <div class="detail-label">رقم الفاتورة / Invoice #</div>
            <div class="detail-value">${invoice.invoiceNumber}</div>
          </div>
          <div class="detail-block">
            <div class="detail-label">العميل / Customer</div>
            <div class="detail-value">${invoice.customerName}</div>
          </div>
          <div class="detail-block">
            <div class="detail-label">تاريخ الإصدار / Issue Date</div>
            <div class="detail-value">${invoice.issueDate}</div>
          </div>
          <div class="detail-block">
            <div class="detail-label">تاريخ الاستحقاق / Due Date</div>
            <div class="detail-value">${invoice.dueDate}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="text-align: right;">الوصف / Description</th>
              <th style="text-align: center;">الكمية / Qty</th>
              <th style="text-align: right;">السعر / Price</th>
              <th style="text-align: right;">الإجمالي / Total</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHTML}
          </tbody>
        </table>

        <div class="summary">
          <div class="summary-block">
            <div class="summary-row">
              <span>الإجمالي الفرعي / Subtotal</span>
              <span>$${invoice.subtotal.toFixed(2)}</span>
            </div>
            ${
              invoice.discount > 0
                ? `
            <div class="summary-row">
              <span>الخصم / Discount</span>
              <span>-$${invoice.discount.toFixed(2)}</span>
            </div>
            `
                : ""
            }
            ${
              invoice.tax > 0
                ? `
            <div class="summary-row">
              <span>الضريبة / Tax</span>
              <span>$${invoice.tax.toFixed(2)}</span>
            </div>
            `
                : ""
            }
            <div class="summary-row total">
              <span>الإجمالي / Total</span>
              <span>$${invoice.totalAmount.toFixed(2)}</span>
            </div>
            <div class="summary-row" style="border: none; margin-top: 10px;">
              <span>طريقة الدفع / Payment Method</span>
              <span style="font-weight: 600;">${invoice.paymentMethod}</span>
            </div>
          </div>
        </div>

        ${
          invoice.notes
            ? `
        <div class="notes">
          <div class="notes-title">ملاحظات / Notes</div>
          <div class="notes-content">${invoice.notes}</div>
        </div>
        `
            : ""
        }
      </div>
    </body>
    </html>
  `
}

/**
 * Print invoice using browser print dialog
 */
export function printInvoice(invoice: InvoiceData): void {
  try {
    console.log("[InvoiceUtils] Starting print invoice:", invoice.invoiceNumber)

    const printWindow = window.open("", "_blank")
    if (!printWindow) {
      throw new Error(
        "Could not open print window. Please check your browser popup settings.",
      )
    }

    const html = generateInvoiceHTML(invoice)
    printWindow.document.write(html)
    printWindow.document.close()

    setTimeout(() => {
      printWindow.print()
    }, 250)
  } catch (error) {
    console.error("[InvoiceUtils] Error printing invoice:", error)
    throw error
  }
}

/**
 * Download invoice as PDF using browser save dialog
 */
export function downloadInvoicePDF(invoice: InvoiceData): void {
  try {
    console.log("[InvoiceUtils] Starting PDF download:", invoice.invoiceNumber)

    const printWindow = window.open("", "_blank")
    if (!printWindow) {
      throw new Error(
        "Could not open PDF window. Please check your browser popup settings.",
      )
    }

    const html = generateInvoiceHTML(invoice)
    printWindow.document.write(html)
    printWindow.document.close()

    setTimeout(() => {
      printWindow.print()
    }, 250)
  } catch (error) {
    console.error("[InvoiceUtils] Error downloading PDF:", error)
    throw error
  }
}

/**
 * Generate WhatsApp message with invoice details
 */
function generateWhatsAppMessage(invoice: InvoiceData): string {
  const itemsList =
    invoice.items && Array.isArray(invoice.items) && invoice.items.length > 0
      ? invoice.items
          .map((item) => {
            const itemDescription =
              item.description || item.productName || "Item"
            return `• ${itemDescription} x${item.quantity || 0} = $${(item.total || 0).toFixed(2)}`
          })
          .join("\n")
      : "No items listed"

  return `
*Invoice: ${invoice.invoiceNumber}*

*Customer:* ${invoice.customerName}
*Issue Date:* ${invoice.issueDate}
*Due Date:* ${invoice.dueDate}

*Items:*
${itemsList}

*Summary:*
Subtotal: $${invoice.subtotal.toFixed(2)}
${invoice.discount > 0 ? `Discount: -$${invoice.discount.toFixed(2)}\n` : ""}${invoice.tax > 0 ? `Tax: $${invoice.tax.toFixed(2)}\n` : ""}
*Total: $${invoice.totalAmount.toFixed(2)}*

Payment Method: ${invoice.paymentMethod}
${invoice.notes ? `\nNotes: ${invoice.notes}` : ""}

---
Sent from Trust Export System
`.trim()
}

/**
 * Normalize phone number to WhatsApp format
 */
function normalizePhoneNumber(phone: string): string {
  // Remove all non-digits
  let cleaned = phone.replace(/\D/g, "")

  // Handle different phone number formats
  // If it starts with 0, remove it and add country code
  if (cleaned.startsWith("0")) {
    cleaned = "20" + cleaned.substring(1)
  }
  // If it starts with 1 (US/Canada style), assume country code needs to be added
  else if (!cleaned.match(/^1\d{10}$/) && cleaned.length === 10) {
    cleaned = "20" + cleaned
  }

  return cleaned
}

/**
 * Share invoice via WhatsApp Web
 */
export function shareViaWhatsApp(invoice: InvoiceData, phoneNumber: string): void {
  try {
    console.log("[InvoiceUtils] Sharing via WhatsApp to:", phoneNumber)

    if (!phoneNumber || phoneNumber.trim() === "") {
      throw new Error("Phone number is required")
    }

    const normalizedPhone = normalizePhoneNumber(phoneNumber)
    if (!normalizedPhone || normalizedPhone.length < 10) {
      throw new Error(`Invalid phone number format: ${phoneNumber}`)
    }

    const message = generateWhatsAppMessage(invoice)
    const encodedMessage = encodeURIComponent(message)

    // WhatsApp Web URL format for sending messages
    const whatsappUrl = `https://web.whatsapp.com/send?phone=${normalizedPhone}&text=${encodedMessage}`

    console.log(
      "[InvoiceUtils] Opening WhatsApp Web with URL:",
      whatsappUrl.substring(0, 50) + "...",
    )

    // Open in new window/tab
    const whatsappWindow = window.open(whatsappUrl, "_blank", "width=800,height=600")

    if (!whatsappWindow) {
      throw new Error(
        "Could not open WhatsApp Web. Please check your browser popup settings.",
      )
    }
  } catch (error) {
    console.error("[InvoiceUtils] Error sharing via WhatsApp:", error)
    throw error
  }
}
