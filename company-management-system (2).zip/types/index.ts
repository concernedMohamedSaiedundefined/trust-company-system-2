export interface Customer {
  id: number
  name: string
  phone: string
  country: string
  city: string
  email: string
  address: string
  businessActivity: string
  totalInvoices: number
  paid: number
  remaining: number
  invoiceCount: number
  paymentType: string
  lastDeal: string
  creditLimit: number
  accountBalance: number
}

export interface Supplier {
  id: number
  name: string
  supplyType: string
  phone: string
  email: string
  address: string
  commercialRegister: string
  taxNumber: string
  totalSupplies: number
  paid: number
  remaining: number
  paymentType: string
  discounts: number
  bonuses: number
  contracts: string[]
  invoices: string[]
  qualityTests: string[]
  accountBalance: number
}

export interface Product {
  id: number
  name: string
  category: string
  type: string
  origin: string
  quantity: number
  unit: string
  pricePerUnit: number
  totalValue: number
  expiryDate: string
  qualityGrade: string
  supplier: string
  location: string
  status: string
  costPrice: number
  sellingPrice: number
  profitMargin: number
}

export interface Shipment {
  id: number
  shipmentNumber: string
  customer: string
  destination: string
  products: string[]
  totalValue: number
  weight: number
  status: string
  shippingDate: string
  estimatedArrival: string
  transportCompany: string
  trackingNumber: string
  documents: string[]
  shippingCost: number
  insuranceCost: number
  customsCost: number
  totalCost: number
}

export interface Employee {
  id: number
  name: string
  position: string
  department: string
  email: string
  phone: string
  hireDate: string
  salary: number
  status: string
  performance: string
}

export interface CustomsDocument {
  id: number
  documentNumber: string
  shipmentId: number
  shipmentNumber: string
  documentType: string
  status: string
  submissionDate: string
  approvalDate?: string
  customsOffice: string
  fees: number
  taxes: number
  totalCost: number
  notes: string
  inspector: string
  portOfEntry: string
  portOfExit: string
  declarant: string
  broker?: string
  hsCode?: string
  attachments: string[]
}

export interface AccountTransaction {
  id: number
  date: string
  type: string
  category: string
  description: string
  amount: number
  reference: string
  status: string
  attachments: string[]
  relatedModule: string
  relatedId: number
  debit: number
  credit: number
  balance: number
}

export interface Sale {
  id: number
  saleNumber: string
  customer: string
  customerId: number
  products: {
    productId: number
    productName: string
    quantity: number
    unitPrice: number
    total: number
  }[]
  subtotal: number
  discount: number
  tax: number
  totalAmount: number
  paymentMethod: string
  saleDate: string
  salesperson: string
  status: string
  paidAmount: number
  remainingAmount: number
}

export interface SaleItem {
  productId: number
  productName: string
  quantity: number
  unitPrice: number
  total: number
}

export interface Purchase {
  id: number
  purchaseNumber: string
  supplier: string
  supplierId: number
  products: {
    productId: number
    productName: string
    quantity: number
    unitPrice: number
    total: number
  }[]
  subtotal: number
  discount: number
  tax: number
  totalAmount: number
  paymentMethod: string
  purchaseDate: string
  buyer: string
  status: string
  paidAmount: number
  remainingAmount: number
  notes?: string
  deliveryDate?: string
  invoiceNumber?: string
}

export interface PurchaseItem {
  productId: number
  productName: string
  quantity: number
  unitPrice: number
  total: number
}

export interface ChatMessage {
  id: number
  senderId: number
  senderName: string
  senderDepartment: string
  recipientId?: number
  recipientName?: string
  channelId?: string
  channelName?: string
  message: string
  timestamp: string
  type: "direct" | "channel" | "announcement"
  attachments?: string[]
  isRead: boolean
  priority: "low" | "medium" | "high" | "urgent"
}

export interface ChatChannel {
  id: string
  name: string
  description: string
  type: "department" | "project" | "general"
  members: number[]
  createdBy: number
  createdAt: string
  isPrivate: boolean
}

export interface Notification {
  id: number
  userId: number
  title: string
  message: string
  type: "info" | "warning" | "error" | "success"
  module: string
  relatedId?: number
  timestamp: string
  isRead: boolean
  priority: "low" | "medium" | "high"
}

export interface BankAccount {
  id: number
  bankName: string
  accountNumber: string
  accountType: string
  balance: number
  currency: string
  manager: string
  openDate: string
  status: string
  branch?: string
  iban?: string
  swiftCode?: string
  creditLimit?: number
}

export interface BankTransaction {
  id: number
  accountId: number
  transactionNumber: string
  date: string
  type: "deposit" | "withdrawal" | "transfer" | "fee" | "interest"
  category: string
  description: string
  amount: number
  balanceAfter: number
  reference?: string
  relatedModule?: string
  relatedId?: number
  status: string
}

export interface InventoryItem {
  id: number
  productId: number
  productName: string
  category: string
  currentStock: number
  recordedStock: number
  difference: number
  unit: string
  lastInventoryDate: string
  location: string
  notes?: string
  status: "match" | "surplus" | "shortage"
  value: number
}

export interface InventorySession {
  id: number
  sessionNumber: string
  startDate: string
  endDate?: string
  performedBy: string
  location: string
  status: "in_progress" | "completed" | "cancelled"
  itemsCount: number
  matchCount: number
  surplusCount: number
  shortageCount: number
  totalValue: number
  notes?: string
}

export interface Expense {
  id: number
  date: string
  category: string
  description: string
  amount: number
  approvedBy: string
  status: string
  receipt: string
  department: string
  accountId: number
}

export interface User {
  id: number
  username: string
  name: string
  email: string
  role: string
  department: string
  permissions: string[]
  lastLogin: string
  status: string
  avatar?: string
  isOnline: boolean
}

export interface LegalCase {
  id: number
  caseNumber: string
  title: string
  type: string
  status: string
  priority: string
  description: string
  plaintiff: string
  defendant: string
  court: string
  lawyer: string
  filingDate: string
  hearingDate?: string
  verdict?: string
  documents: string[]
  notes: string
  estimatedCost: number
  actualCost: number
  relatedModule?: string
  relatedId?: number
}

export interface Contract {
  id: number
  contractNumber: string
  title: string
  type: string
  parties: string[]
  startDate: string
  endDate: string
  value: number
  status: string
  terms: string
  renewalTerms?: string
  penaltyClause?: string
  documents: string[]
  signatories: string[]
  department: string
  notes: string
}

export interface FoodSafetyTest {
  id: number
  testNumber: string
  productName: string
  productId: number
  batchNumber: string
  testType: string
  testDate: string
  laboratory: string
  result: string
  score: number
  expiryDate: string
  inspector: string
  standards: string[]
  remarks: string
  documents: string[]
  status: string
  correctionRequired: boolean
  correctionDeadline?: string
}

export interface FoodSafetyCertificate {
  id: number
  certificateNumber: string
  certificateType: string
  issuingAuthority: string
  issueDate: string
  expiryDate: string
  scope: string
  status: string
  products: string[]
  inspector: string
  documents: string[]
  renewalDate?: string
  notes: string
}

export interface QualityIncident {
  id: number
  incidentNumber: string
  title: string
  severity: string
  date: string
  location: string
  product?: string
  description: string
  reportedBy: string
  assignedTo: string
  status: string
  rootCause?: string
  correctiveAction?: string
  preventiveAction?: string
  deadline: string
  documents: string[]
  verificationDate?: string
  verifiedBy?: string
}
